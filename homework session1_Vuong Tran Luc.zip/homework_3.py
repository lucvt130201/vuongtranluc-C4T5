a = int(input("temprature in celsius ="))
b = float((a*1.8)+32)

print(a, " (C) = ",b," (F)")