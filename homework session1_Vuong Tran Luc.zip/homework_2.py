rad = int(input("radius ="))
a = float(3.14*rad*rad)

print("Area =", " ", a)